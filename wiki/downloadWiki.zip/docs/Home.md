**Project Description**
WF2WPF helps .NET developers learn WPF by converting their existing Windows Forms projects into WPF projects. WF2WPF is developed in C#. It currently only supports C# projects, but VB support is planned and in development.

This project is intended to help developers learn how their Windows Forms knowledge can be translated into Windows Presentation Foundation. It does so by taking Windows Forms projects and performing a basic translation of the source code and project file into a corresponding WPF Project.

With any utility like this, the obvious question is "will this work for real-world code?". The answer to this question of course depends on the real-world code in question. There is almost an infinite number of ways to write .NET/Windows Forms code. Can this converter (or any converter) handle all of the possible Windows Forms applications that can be written? Absolutely not. 

What this converter does do is serve as an educational resource; it has a simple, easy to modify architecture that enables you to clearly see how you Windows Forms assets are being converted. We don't try to convert every asset, there are simply something things (even in a basic Windows Form application) that do not translate well into WPF.

We took a best-guess on how to translate the basic assets in WF and WPF, but your feedback would be greatly appreciated.

WF2WPF is still a work in progress, so far, we can do the following:

* Basic Windows Forms controls
* Carry over event handling code
* Only C# projects (VB is coming soon!)
* Datagrids support is coming soon!

We'll keep posting more code as we get further along.

Thanks!